/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author usuario
 */
public class Envio {
    private int ID; 
    private String fecha; 
    private String prioridad; 

    public Envio(int ID, String fecha, String prioridad) {
        this.ID = ID;
        this.fecha = fecha;
        this.prioridad = prioridad;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(String prioridad) {
        this.prioridad = prioridad;
    }

    @Override
    public String toString() {
        return "Envio{" + " ID: " + ID + "\n, fecha: " + fecha + ", prioridad: " + prioridad + '}';
    }
    
    
}
