// ###### Parte 2, con insertion sort únicamente #######
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author usuario
 */
public class Ordenamiento_2 {
        public static boolean compararFechas(Envio envio1, Envio envio2){
        String fecha1 = envio1.getFecha();
        String fecha2 = envio2.getFecha();

        //Utilizo compare to, que en resumen devuelve -1 si el string es menor, 1 si es mayor, 0 si es igual
        int resultado = fecha1.compareTo(fecha2);

        if(resultado == 0){
           // System.out.println("Las fechas de los productos con ID: " + envio1.getID() + " y " + envio2.getID() + " son iguales");
            return false;
        }else if(resultado > 0){
          //  System.out.println("La fecha del producto con ID: " + envio1.getID() + " (" + fecha1 + ") es posterior a la del producto con ID: " + envio2.getID() + " (" + fecha2 + ")");
            return true; 
        }else{
           // System.out.println("La fecha del producto con ID: " + envio1.getID() + " (" + fecha1 + ") es anterior a la del producto con ID: " + envio2.getID() + " (" + fecha2 + ")");
            return false; 
        }
    }

    public static boolean compararPrioridad(Envio envio1, Envio envio2){
        String prioridad1 = envio1.getPrioridad();
        String prioridad2 = envio2.getPrioridad();

        // Si envio1 es Normal Y envio2 es Urgente se debe intercambiar
        if(prioridad1.equals("Normal") && prioridad2.equals("Urgente")){
            return true;
        }
        return false;
    }
    
    public static boolean compararID(Envio envio1, Envio envio2){
        int id1 = envio1.getID();
        int id2 = envio2.getID();  
        // Si un ID es menor, entonces irá primero porque se creó primero
        if(id1 > id2){
            //System.out.println("El ID del primer producto (" + id1 + ") es mayor que el ID del segundo producto (" + id2 + ")");
            return true;
        }else{
            //System.out.println("El ID del segundo producto (" + id2 + ") es mayor que el ID del primer producto (" + id1 + ")");
            return false;
        }
    }
    
    public static void intercambiar(ArrayList<Envio> envios, int i, int j){
        //una variable temporal que usa .get(i) lo que quiere decir que 
        //va a obtener la posicion i de la lista de objetos envio
        Envio temp = envios.get(i);
        //Lo reemplazo por la posicion j, que será la siguiente 
        //lo e siguiente se plantea en el bubble sort formal
        envios.set(i, envios.get(j));
        //Re asigno la variable temporal a un valior anterior a j
        envios.set(j, temp);
        
        System.out.println("\nLista después del cambio: " + envios);
    }
    
    public static void crearArchivoIn(String metodo, ArrayList<Envio> desordenada, ArrayList<Envio> ordenada){
        System.out.println("Creando archivo....");
        try(PrintWriter writer = new PrintWriter(new FileWriter("ArchivoResultados_In.txt"))){
            writer.println("##### Metodo utilizado: "+ metodo + " #####");
            
            for(Envio envio : desordenada){
                writer.println("ID: " + envio.getID() + 
                         ", Fecha: " + envio.getFecha() + 
                         ", Prioridad: " + envio.getPrioridad());
            }
            
            writer.println("\n\nResultado final: \n\n");
            
            for(Envio envio: ordenada){
                writer.println("ID: " + envio.getID() + 
                         ", Fecha: " + envio.getFecha() + 
                         ", Prioridad: " + envio.getPrioridad());                
            }
            
            
        }catch(IOException e){
            System.out.println("No funciono");
        }
    }
    public static boolean debeIntercambiar(Envio envio1, Envio envio2){
        //construimos una funcion que guarde los if anidados
        if(compararFechas(envio1, envio2)){
            return true;
        }else if(envio1.getFecha().equals(envio2.getFecha())){
            if(compararPrioridad(envio1, envio2)){
                return true;
            }else if(envio1.getPrioridad().equals(envio2.getPrioridad())){
                if(compararID(envio1, envio2)){
                    return true;
                }
            }
        }
        return false;
    }
    
    
    public static ArrayList<Envio> insertionSort(ArrayList<Envio> envios){
        ArrayList<Envio> listaOrd = new ArrayList<>(envios);
        //insertion sort debe empezar en uno porque no hay nada a su izquierda
        for(int i = 1; i < listaOrd.size(); i++){
            Envio elementoActual = listaOrd.get(i);
            //j debe estar una posicion atrás de i
            int j= i -1;
            
            
            //tomamos al elemento anterior como primero
            while(j >= 0 && debeIntercambiar(listaOrd.get(j), elementoActual)){
                listaOrd.set(j+1, listaOrd.get(j));
                j--;
                System.out.println("Lista despues del cambio: " + listaOrd);
            }
            listaOrd.set(j+1, elementoActual);
            System.out.println("Lista despues del cambio: " + listaOrd);
        }
        return listaOrd;
    }
    
    public static void main(String[] args) {
        
        ArrayList<Envio> envios = new ArrayList<>();
        
        //set de datos pequeño
        /*
        Envio envio1 = new Envio(1, "2025-11-02", "Urgente");
        Envio envio2 = new Envio(2, "2026-11-02", "Normal");
        Envio envio3 = new Envio(3, "2025-11-02", "Normal");
        Envio envio4 = new Envio(4, "2025-01-06", "Normal");
        Envio envio5 = new Envio(5, "2025-11-31", "Urgente");
        Envio envio6 = new Envio(6, "2025-12-01", "Urgente");
        
        envios.add(envio1);
        envios.add(envio2);
        envios.add(envio3);
        envios.add(envio4);
        envios.add(envio5);
        envios.add(envio6);
        */
        
        //set de datos grande
        
        envios.add(new Envio(5, "2025-06-15", "Normal"));
        envios.add(new Envio(2, "2025-06-15", "Normal"));
        envios.add(new Envio(7, "2025-06-15", "Urgente"));
        envios.add(new Envio(1, "2025-06-15", "Normal"));
        envios.add(new Envio(8, "2025-03-10", "Normal"));
        envios.add(new Envio(3, "2025-09-20", "Urgente"));
        envios.add(new Envio(9, "2025-07-01", "Urgente"));
        envios.add(new Envio(4, "2025-07-01", "Normal"));
        envios.add(new Envio(6, "2025-04-05", "Normal"));
        envios.add(new Envio(10, "2025-05-12", "Urgente"));
        envios.add(new Envio(11, "2024-12-31", "Normal"));
        envios.add(new Envio(12, "2026-01-01", "Urgente"));
        
        System.out.println(envios);
        ArrayList<Envio> enviosDesordenados = new ArrayList<>(envios);


        ArrayList<Envio> enviosOrdIn = insertionSort(envios);
        System.out.println("\n\nLista Final: " + enviosOrdIn);
        crearArchivoIn("Insertion Sort", enviosDesordenados, enviosOrdIn);


    } 
}
