class Envio:
    def __init__(self, id, fecha, prioridad):
        # Por convención, los atributos con guion bajo al inicio
        # se consideran "no públicos" y no deben ser accedidos directamente.
        self._id = id
        self._fecha = fecha
        self._prioridad = prioridad

    # Getters
    def get_ID(self):
        return self._id

    def get_fecha(self):
        return self._fecha

    def get_prioridad(self):
        return self._prioridad

    # alias para compatibilidad con ordenamiento.py
    def get_id(self):
        return self.get_ID()

    # Setters
    def set_id(self, id):
        self._id = id

    def set_fecha(self, fecha):
        self._fecha = fecha

    def set_prioridad(self, prioridad):
        self._prioridad = prioridad

    def __str__(self):
        return (f"Envio{{ ID: {self._id}\n, "
                f"fecha: {self._fecha}, "
                f"prioridad: {self._prioridad}}}")

    def __repr__(self):
        return self.__str__()
