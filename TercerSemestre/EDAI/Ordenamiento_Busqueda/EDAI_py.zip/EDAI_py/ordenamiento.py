

from Envio import Envio


def compararFechas(envio1, envio2):
    fecha1 = envio1.get_fecha()
    fecha2 = envio2.get_fecha()

    if(fecha1 > fecha2):
        return True
    elif(fecha1 < fecha2):
        return False
    elif(fecha1 == fecha2):
        return False

def compararPrioridades(envio1, envio2):
    prioridad1 = envio1.get_prioridad()
    prioridad2 = envio2.get_prioridad()

    if(prioridad1 == "Normal" and prioridad2 == "Urgente"):
        return True
    else: 
        return False

def compararID(envio1, envio2):
    ID1 = envio1.get_id()
    ID2 = envio2.get_id()

    if(ID1 > ID2):
        return True
    else:
        return False


def debeIntercambiar(envio1, envio2):
    if(compararFechas(envio1, envio2)):
        return True
    elif(envio1.get_fecha() == envio2.get_fecha()):
        if(compararPrioridades(envio1, envio2)):
            return True
        elif(envio1.get_prioridad() == envio2.get_prioridad()):
            if(compararID(envio1, envio2)):
                return True
            
    else:
        return False

def moverElementosBurbuja(envios, i, j):
    #Cambio el orden de los numeros
    envios[i], envios[j] = envios[j], envios[i]
    print("Lista despues del cambio:", envios)
    

def bubbleSort(envios):
    for i in range(len(envios) - 1):
        for j in range(len(envios)-1-i):
            if(debeIntercambiar(envios[j], envios[j+1])):
                moverElementosBurbuja(envios, j, j+1)
                print("Lista despues del cambio:", envios)

    return envios

def crearArchivo(metodo, desordenada, ordenada):
    print("Creando archivo....")
    try:
        with open("ArchivoResultados.txt", "w", encoding="utf-8") as writer:
            writer.write("##### Metodo utilizado: " + metodo + " #####\n")
            for envio in desordenada:
                writer.write("ID: " + str(envio.get_id()) + ", Fecha: " + str(envio.get_fecha()) + ", Prioridad: " + str(envio.get_prioridad()) + "\n")
            writer.write("\n\nResultado final: \n\n")
            for envio in ordenada:
                writer.write("ID: " + str(envio.get_id()) + ", Fecha: " + str(envio.get_fecha()) + ", Prioridad: " + str(envio.get_prioridad()) + "\n")
    except Exception:
        print("No funciono")

def crearArchivoIn(metodo, desordenada, ordenada):
    print("Creando archivo....")
    try:
        with open("ArchivoResultados_In.txt", "w", encoding="utf-8") as writer:
            writer.write("##### Metodo utilizado: " + metodo + " #####\n")
            for envio in desordenada:
                writer.write("ID: " + str(envio.get_id()) + ", Fecha: " + str(envio.get_fecha()) + ", Prioridad: " + str(envio.get_prioridad()) + "\n")
            writer.write("\n\nResultado final: \n\n")
            for envio in ordenada:
                writer.write("ID: " + str(envio.get_id()) + ", Fecha: " + str(envio.get_fecha()) + ", Prioridad: " + str(envio.get_prioridad()) + "\n")
    except Exception:
        print("No funciono")


def main():
    envios = []

    envios.append(Envio(5, "2025-06-15", "Normal"))
    envios.append(Envio(2, "2025-06-15", "Normal"))
    envios.append(Envio(7, "2025-06-15", "Urgente"))
    envios.append(Envio(1, "2025-06-15", "Normal"))
    envios.append(Envio(8, "2025-03-10", "Normal"))
    envios.append(Envio(3, "2025-09-20", "Urgente"))
    envios.append(Envio(9, "2025-07-01", "Urgente"))
    envios.append(Envio(4, "2025-07-01", "Normal"))
    envios.append(Envio(6, "2025-04-05", "Normal"))
    envios.append(Envio(10, "2025-05-12", "Urgente"))
    envios.append(Envio(11, "2024-12-31", "Normal"))
    envios.append(Envio(12, "2026-01-01", "Urgente"))
    envios.append(Envio(13, "2025-10-15", "Normal"))
    envios.append(Envio(14, "2025-10-14", "Urgente"))
    envios.append(Envio(15, "2025-10-15", "Urgente"))

    print(envios)
    enviosDesordenados = list(envios)

    enviosOrd = bubbleSort(list(envios))
    print("\n\nLista Final: " + str(enviosOrd))

    crearArchivo("BubbleSort", enviosDesordenados, enviosOrd)


if __name__ == "__main__":
    main()