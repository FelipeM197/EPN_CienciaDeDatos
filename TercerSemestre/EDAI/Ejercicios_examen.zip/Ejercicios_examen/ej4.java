
/*
 * Autores: 
 * Felipe Merino
 * Aidan Carrasco
 * Deysi Guachamin
 */
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Random;
/*
 4. Generar aleatoriamente 20 numeros en un rango de 1 al 99, sumar los dígitos de cada numero y luego ordenarlos empleando un algoritmo de ordenamiento Ej. {4,82,47,13,25....} -> {4,
8+2, 4+7, 1+3, 2+5,...} -> {4, 10, 11, 4, 7, ....} →→> {4,4,7,10,11,...}

 */
public class ej4 {
    public static void main(String[] args) {
            
        ArrayList<Integer> numberList = new java.util.ArrayList<>();
        Random randNum = new Random();
        int listSize = 20;
        int maxBound = 99; 
        
        for (int i = 0; i < listSize; i++) {
            numberList.add(randNum.nextInt(maxBound) + 1);
        }

        System.out.println(numberList);
        ArrayList<Integer> sumada = sumar(numberList);
        System.out.println(sumada);
        intentoOrdenar(sumada);
        System.out.println(sumada);

    
    }

    public static ArrayList<Integer> sumar(ArrayList<Integer> numeros){
        int resultado = 0;
        ArrayList<Integer> listaSumada = new ArrayList<>();
        for(int num : numeros){
            resultado = (num%10) + (num/10);
            listaSumada.add(resultado);
        }
        return listaSumada;
    }

    public static void intentoOrdenar(ArrayList<Integer> lista){
        int valorMaximo = lista.get(0);
        for(int i = 0; i < lista.size(); i++){
            if(lista.get(i) > valorMaximo){
                valorMaximo = lista.get(i);
            }
        }
        // +1 porque contamos el 0, de 0 a 11 hay 12 numeros por ejemplo
        int[] tamanio = new int[valorMaximo + 1];

        for(int i = 0; i < lista.size(); i++){
            // obtengo el numero y eso sera el indice donde sumare 1
            tamanio[lista.get(i)] += 1;
        }

        int indice = 0;
        //Existen valorMaximo cajas en el array
        for(int i = 0; i < valorMaximo; i++){
            while(tamanio[i] > 0){
                lista.set(indice++, i);
                tamanio[i]--;
            }

        }


    }
}
