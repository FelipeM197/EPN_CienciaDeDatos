
import java.util.ArrayList;

/*
 * Autores: 
 * Felipe Merino
 * Aidan Carrasco
 * Deysi Guachamin
 */
/*
 5. Ingresar su nombre completo, contar cuantos dígitos tiene cada palabra 
 y ordenar empleando un un algoritmo de ordenamiento, de mayor a menor.

 */

public class ej5 {
    public static void main(String[] args) {
            
        String nombreCompleto = "Andresorski Feli Merino Bravo";
        String[] palabras = nombreCompleto.split(" ");
        ArrayList<String> nombres = new ArrayList<>();

        for(String palabra : palabras){
            nombres.add(palabra);
        }
        System.out.println(nombres);

        analizarTamanio(nombres);
        System.out.println(nombres);



    }

    public static void analizarTamanio(ArrayList<String> nombres){
        for(int i = 0; i < nombres.size() -1; i++){
            for(int j = 0; j < nombres.size() - i - 1; j++){

                if(nombres.get(j).length() < nombres.get(j+1).length()){


                    String temp = nombres.get(j);

                    nombres.set(j, nombres.get(j+1));
                    nombres.set(j+1, temp);

                    System.out.println("Lista despues del cambio: " + nombres);
                }
            }
        }
    }

}