/*
 * Autores: 
 * Felipe Merino
 * Aidan Carrasco
 * Deysi Guachamin
 */

/*
 1. Ingresar una frase y aplicando un algoritmo de ordenamiento, 
 ordenar alfabéticamente cada una de las letras de la frase, excluyendo los espacios.

 */
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;
import java.util.Random;
public class ej1 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese una frase: ");
        String frase1 = sc.nextLine();
        String frase = frase1.toLowerCase();
        ordenarLetrasBurbuja(frase);
    }


    public static void ordenarLetrasBurbuja(String frase){
        StringBuilder fraseSinEspacios = new StringBuilder();
        // Metodo toCharArray convierte la frase en un arreglo de caracteres
        char[] arregloLetras = frase.toCharArray();
        for(int i = 0; i < arregloLetras.length - 1; i++){
            for(int j = 0; j < arregloLetras.length -1 - i; j++){
                if(arregloLetras[j] > arregloLetras[j+1]){
                    char temp = arregloLetras[j];
                    arregloLetras[j] = arregloLetras[j+1];
                    arregloLetras[j+1] = temp;
                    System.out.println("Arreglo en la iteracion " + (i+1) + ": " + Arrays.toString(arregloLetras));
                }
            }

        }
        // Transformo en un arrayList que no tendra los espacios
        ArrayList<Character> listaLetras = new ArrayList<>();
        for(char letra : arregloLetras){
            if(letra != ' '){
                listaLetras.add(letra);
            }
        }
        System.out.println("Lista sin espacios: " + listaLetras);

        for(char letra : listaLetras){
            fraseSinEspacios.append(letra);
        }
        String fraseOrdenada = fraseSinEspacios.toString();
        System.out.println("Frase ordenada alfabeticamente sin espacios: " + fraseOrdenada);

    }



}
    
