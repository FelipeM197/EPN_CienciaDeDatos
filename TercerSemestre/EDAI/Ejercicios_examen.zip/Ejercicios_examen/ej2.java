/*
 * Autores: 
 * Felipe Merino
 * Aidan Carrasco
 * Deysi Guachamin
 */

/*
 2. En una palabra ingresada por teclado, encontrar usando la búsqueda binara, todas las letras

 */
import java.util.Arrays;
import java.util.Scanner;   
import java.util.ArrayList;

public static void main(String[] args){
    Scanner sc = new Scanner(System.in);
    System.out.println("Ingrese una palabra: ");
    String palabra1 = sc.nextLine();
    String palabra = palabra1.toLowerCase();
    
    char[] letras = palabra.toCharArray();
    ArrayList<Character> listaLetras = new ArrayList<>();
    for(char letra : letras){
        listaLetras.add(letra);
    }

    bubbleSort(listaLetras);
    System.out.println("Lista ordenada: " + listaLetras);    
    for(char letra : letras){
        char buscada = busquedaBinaria(listaLetras, letra);
        System.out.println("Letra buscada: " + letra + " Resultado de la busqueda: " + buscada);
    }
    
    

}

public static char busquedaBinaria(ArrayList<Character> listaLetras, char letra){

    int izquierda = 0;
    int derecha = listaLetras.size() - 1;


    //Si aun existen elementos entre derecha e izquierda
    while(izquierda <= derecha){
        int medio = izquierda + (derecha - izquierda)/2;
        char elementoMedio = listaLetras.get(medio);
        
        if(elementoMedio == letra){
            System.out.println("Letra " + letra + " encontrada en la posicion " + medio);
            return elementoMedio;
        }
        
        if(elementoMedio < letra){
            izquierda = medio + 1;
        }else{
            derecha = medio - 1;
        }
    }
    System.out.println("Letra no encontrada");
    return '\0';

}


public static void bubbleSort(ArrayList<Character> list) {
    int n = list.size();
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (list.get(j) > list.get(j + 1)) {
                // Intercambiar elementos
                char temp = list.get(j);
                list.set(j, list.get(j + 1));
                list.set(j + 1, temp);
            }
        }
    }
}
