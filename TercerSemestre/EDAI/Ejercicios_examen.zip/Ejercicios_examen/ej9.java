/*
 9. Aplicar un método de ordenamiento para organizar las fechas de cumpleaños siguientes:
- 23/Sep/1999, 14/Feb/2000, 13/Oct/2005
 */
import java.util.ArrayList;
import java.util.Arrays;

public class ej9 {
    public static void main(String[] args) {
        String[] fechas = {"23/Sep/2005", "14/Feb/2000", "13/Oct/1900"};
        
        System.out.println("Fechas originales: " + Arrays.toString(fechas));
        
        ArrayList<String> listaFechas = new ArrayList<>();
        for(String fecha : fechas){
            String fechaForm = formatoFechas(fecha);
            listaFechas.add(fechaForm);
        }


        System.out.println("Fechas formateadas: " + listaFechas);
        listaFechas = insertion(listaFechas);
        System.out.println("Fechas ordenadas: " + listaFechas);

    }

    public static String mesAFormatoNumerico(String mes){
        switch (mes) {
            case "Jan":
                return "01";
            case "Feb":
                return "02";
            case "Mar":
                return "03";
            case "Apr":
                return "04";
            case "May":
                return "05";
            case "Jun":
                return "06";
            case "Jul":
                return "07";
            case "Aug":
                return "08";
            case "Sep":
                return "09";
            case "Oct":
                return "10";
            case "Nov":
                return "11";
            case "Dec":
                return "12";
            default:
                return mes;
        }
    }

    public static String formatoFechas(String fechas){
        StringBuilder sb = new StringBuilder();
        String[] partes = fechas.split("/");
        String dia = partes[0];
        String mes = mesAFormatoNumerico(partes[1]);
        String anio = partes[2];

        //Formato anio, mes, dia 
        partes[0] = anio;
        partes[1] = mes;    
        partes[2] = dia;
        for(String parte : partes){
            sb.append(parte).append("/");
        }

        String fechaFormateada = sb.toString();
        System.out.println("Fecha formateada: " + fechaFormateada);
        return fechaFormateada;
    }

    public static ArrayList<String> insertion(ArrayList<String> fechas){
        int n = fechas.size();
        for(int i = 1; i < n; i++){
            String elementoActual = fechas.get(i);
            int j = i -1;
            int debeIntercambiar = fechas.get(j).compareTo(elementoActual);
            while (j>= 0 && debeIntercambiar == 1) {
                fechas.set(j+1, fechas.get(j));
                j--;
            }
            fechas.set(j + 1, elementoActual);
        }
        return fechas;
    }
}



