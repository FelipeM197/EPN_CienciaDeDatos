
import java.util.ArrayList;
import java.util.Arrays;

/*  6. Aplicar un algoritmo de ordenamiento, colocar en orden descendente, según la fecha, los siguientes mensajes extraídos de redes sociales:
1. 23-11-2025 "Hola mundo"
2.
12-04-2025 "estoy feliz"
12-04-2025 "sali a comer"
4.
 */

public class ej6 {
    public static void main(String[] args) {
        ArrayList<String> fechaMensaje = new ArrayList<>();
        ArrayList<String> fechas = new ArrayList<>();
        ArrayList<String> mensajes = new ArrayList<>();
        fechaMensaje.add("23-11-2025 \"Hola mundo\"");
        fechaMensaje.add("12-04-2025 \"estoy feliz\"");
        fechaMensaje.add("12-04-2025 \"sali a comer\"");
        
        separaMensajeFecha(fechaMensaje, fechas, mensajes);


        System.out.println(fechas);
        System.out.println(mensajes);

        ordenarPorfecha(fechas, mensajes);

        System.out.println(fechas);
        System.out.println(mensajes);

        ArrayList<String> resultadoFinal = new ArrayList<>();

        for(int i = 0; i < fechas.size(); i ++){
            resultadoFinal.add(fechas.get(i) + " " + mensajes.get(i));
            
        }

        System.out.println(resultadoFinal);


        
    }        

    public static void ordenarPorfecha(ArrayList<String> fechas, ArrayList<String> mensajes){
        for(int i = 0; i < fechas.size() -1; i++){
            for(int j = 0; j < fechas.size() -i -1; j++){
                String fecha1 = fechas.get(j);
                String fecha2 = fechas.get(j+1);
                String mensaje1 = mensajes.get(j);
                String mensaje2 = mensajes.get(j+1);

                if(fecha1.compareTo(fecha2) == 1){
                    String temp = fecha1;
                    String tempM = mensaje1;
                    fechas.set(j+1, temp);
                    fechas.set(j, fecha2);
                    mensajes.set(j+1, tempM);
                    mensajes.set(j, mensaje2);
                }
            }
        }
    }

    public static void separaMensajeFecha(ArrayList<String> fechaMensaje,ArrayList<String> fechas, ArrayList<String> mensajes){
        for(int i = 0; i < fechaMensaje.size(); i++){
            String actual = fechaMensaje.get(i);

            // obligo que sea 2 para que solo se separe en 2 partes y no en cuantas haya espacios
            String[] separador = actual.split(" ", 2);


            if(separador.length == 2){
                fechas.add(separador[0]);
                mensajes.add(separador[1]);
            }
        }
    }

    




}
