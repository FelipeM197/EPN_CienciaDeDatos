/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
/*
 * Autores: 
 * Felipe Merino
 * Aidan Carrasco
 * Deysi Guachamin
 */

import java.util.ArrayList;
import java.util.List;

public class Ejercicio7 {

    public static void main(String[] args) {
        List<Double> areasList = new ArrayList<>();

        // Generar 10 triángulos rectángulos con lados aleatorios
        for (int i = 1; i <= 10; i++) {
            double base = Math.random() * 10 + 1;   // entre 1 y 10
            double altura = Math.random() * 10 + 1; // entre 1 y 10

            double area = (base * altura) / 2;
            areasList.add(area);

            System.out.printf("Triángulo %d -> base: %.2f, altura: %.2f, área: %.2f%n",
                    i, base, altura, area);
        }

        // Convertir la lista en arreglo de enteros (redondeando las áreas)
        double[] areas = new double[areasList.size()];
        for (int i = 0; i < areasList.size(); i++) {
            areas[i] = areasList.get(i);
        }

        // Llamar al método de ordenamiento burbuja
        ordenadorBurbuja(areas);
    }

    // Método para ordenar con burbuja
    public static void ordenadorBurbuja(double[] array) {
        double temp;
        boolean cambio;


        while (true) {
            cambio = false;
            for (int i = 1; i < array.length; i++) {
                int j = i - 1;
                if (array[i] < array[j]) {
                    temp = array[i];
                    array[i] = array[j];
                    array[j] = temp;
                    cambio = true;
                }
            }


            // Si no hubo cambios, ya está ordenado
            if (!cambio) break;
        }

        System.out.println("\nÁreas ordenadas de menor a mayor:");
        for (double val : array) {
            System.out.printf("%.2f ", val);
        }
        System.out.println();
    }
}
