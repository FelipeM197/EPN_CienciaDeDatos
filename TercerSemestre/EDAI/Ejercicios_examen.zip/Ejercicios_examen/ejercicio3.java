import java.util.Arrays;

/**
 * Aplicando un algoritmo de ordenamiento con los siguientes datos
 * {4,9,1,0,3,6,7,8} imprimir su
 * resultado luego de solo 4 pasadas.
 */
public class ejercicio3 {
    public static void main(String[] args) {
        int[] numeros = { 4, 9, 1, 0, 3, 6, 7, 8 };

        bubbleSort(numeros);
    }

    public static void bubbleSort(int[] numeros) {
        int n = numeros.length;
        for (int i = 0; i < 4 ; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (numeros[j] > numeros[j + 1]) {

                    int temp = numeros[j];
                    numeros[j] = numeros[j + 1];
                    numeros[j + 1] = temp;

                }
            }
            System.out.println("Pasada numero " + i + ": " +Arrays.toString(numeros));
        }
    }
}
